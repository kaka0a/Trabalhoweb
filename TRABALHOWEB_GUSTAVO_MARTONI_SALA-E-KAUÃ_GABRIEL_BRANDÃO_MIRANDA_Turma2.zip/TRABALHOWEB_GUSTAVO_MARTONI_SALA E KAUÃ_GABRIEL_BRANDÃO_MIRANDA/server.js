const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const Banco = require('./src/model/Banco');
const VendaDAO = require('./src/controller/VendaDAO');
const Cliente = require('./src/model/Cliente')
const ClienteDAO = require('./src/controller/ClienteDAO')
const Item = require('./src/model/Item')
const ItemDAO = require('./src/controller/ItemDAO')
const DepartamentoDAO = require('./src/controller/DepartamentoDAO')
const Venda = require('./src/model/Venda')
const Produto = require('./src/model/Produto')
const ProdutoDAO = require('./src/controller/ProdutoDAO')

const app = express();

app.use(express.static('public'));
app.use('/images', express.static(path.join(__dirname, 'public/images')));
app.use('/template', express.static(path.join(__dirname, 'public/template')));
app.set('view engine', 'ejs');
app.set('views', './src/view');

app.use(session({
    secret: 'corinthiansomaior',
    resave: false,
    saveUninitialized: true
}));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const verificarLoginParaCompra = (req, res, next) => {
    if (req.session.usuario) {
        next();
    } else {
        res.redirect('/template/login.html');
    }
};

app.get('/', (req, res) => {
  res.sendFile('index.html', { root: '.' });
});

app.get('/login', (req, res) => {
    res.redirect('/template/login.html');
});

app.get('/cadastro', (req, res) => {
    res.redirect('/template/cadastrar.html');
});

app.post('/login', async (req, res) => {
    try {
        const { login, senha } = req.body;
        
        if (!login || !senha) {
            return res.redirect('/template/login.html?erro=campos');
        }

        const clienteDAO = new ClienteDAO();
        const cliente = await clienteDAO.login(login, senha);
        
        if (cliente) {
            req.session.usuario = cliente;
            res.redirect('/');
        } else {
            res.redirect('/template/login.html?erro=invalido');
        }
    } catch (erro) {
        console.error(erro);
        res.redirect('/template/login.html?erro=servidor');
    }
});

app.post('/cadastrar', async (req, res) => {
    try {
        const { nome, login, senha } = req.body;
        
        if (!nome || !login || !senha) {
            return res.json({ 
                success: false, 
                message: 'Por favor, preencha todos os campos' 
            });
        }

        const clienteDAO = new ClienteDAO();
        
      
        const clienteExistente = await clienteDAO.buscarPorLogin(login);
        if (clienteExistente) {
            return res.json({ 
                success: false, 
                message: 'Este login já está em uso' 
            });
        }

        const cliente = new Cliente();
        cliente.nome = nome;
        cliente.login = login;
        cliente.senha = senha;

        await clienteDAO.gravar(cliente);
        
        res.json({ 
            success: true, 
            message: 'Cadastro realizado com sucesso' 
        });
    } catch (erro) {
        console.error(erro);
        res.json({ 
            success: false, 
            message: 'Erro ao realizar cadastro' 
        });
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

app.get('/ListarDep', async (req, res) => {
    try {
        const departamentoDAO = new DepartamentoDAO();
        const departamentos = await departamentoDAO.listar();
        res.render('departamento', { tabela: departamentos });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao listar departamentos');
    }
});

app.get('/ListarProd/:id', async (req, res) => {
    try {
        const produtoDAO = new ProdutoDAO();
        const produtos = await produtoDAO.listar(req.params.id);
        res.render('produto', { tabela: produtos });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao listar produtos');
    }
});

app.post('/comprar', async (req, res) => {
    try {
        const { produto, qtde } = req.body;
        const produtoObj = JSON.parse(produto);
        const quantidade = parseInt(qtde);

        // Verificar estoque antes de adicionar ao carrinho
        const produtoDAO = new ProdutoDAO();
        const produtoAtual = await produtoDAO.buscarPorCodigo(produtoObj.codigo);

        if (!produtoAtual || produtoAtual.qtde < quantidade) {
            return res.redirect('/ListarDep'); // Redireciona de volta para a lista de produtos
        }

        // Inicializa o carrinho se não existir
        if (!req.session.carrinho) {
            req.session.carrinho = [];
        }

        // Verifica se o produto já está no carrinho
        const itemExistente = req.session.carrinho.find(
            item => item.codigo === produtoObj.codigo
        );

        if (itemExistente) {
            // Verifica se a soma das quantidades não excede o estoque
            if ((itemExistente.qtde + quantidade) > produtoAtual.qtde) {
                return res.redirect('/ListarDep'); // Redireciona se exceder o estoque
            }
            itemExistente.qtde += quantidade;
        } else {
            req.session.carrinho.push({
                codigo: produtoObj.codigo,
                descricao: produtoObj.descricao,
                preco: produtoObj.preco,
                qtde: quantidade,
                imagem: produtoObj.imagem
            });
        }

        res.redirect('/mostrarCarrinho');
    } catch (erro) {
        console.error('Erro ao adicionar ao carrinho:', erro);
        res.redirect('/ListarDep'); // Em caso de erro, redireciona para a lista
    }
});

app.get('/template/topo', (req, res) => {
    res.sendFile('topo.html', { root: './public/template' });
});

app.get('/bemvindo', (req, res) => {
    res.render('bemvindo', { 
        usuario: req.session.usuario || null
    });
});

app.get('/mostrarCarrinho', (req, res) => {
    const carrinho = req.session.carrinho || [];
    const totalCarrinho = carrinho.reduce((total, item) => 
        total + (item.preco * item.qtde), 0);
    
    res.render('carrinho', { 
        carrinho: carrinho,
        totalCarrinho: totalCarrinho,
        usuario: req.session.usuario
    });
});

app.post('/atualizarCarrinho', (req, res) => {
    const { index, delta } = req.body;
    const carrinho = req.session.carrinho;

    if (carrinho && carrinho[index]) {
        carrinho[index].qtde = Math.max(1, carrinho[index].qtde + delta);
        res.json({ success: true });
    } else {
        res.json({ success: false });
    }
});

app.post('/removerItem', (req, res) => {
    const { index } = req.body;
    if (req.session.carrinho && req.session.carrinho[index]) {
        req.session.carrinho.splice(index, 1);
        res.json({ success: true });
    } else {
        res.json({ success: false });
    }
});

app.get('/verificarLogin', (req, res) => {
    res.json({ 
        usuario: req.session.usuario || null 
    });
});

app.get('/finalizar-compra', verificarLoginParaCompra, async (req, res) => {
    if (!req.session.usuario || !req.session.carrinho || req.session.carrinho.length === 0) {
        return res.redirect('/bemvindo');
    }

    try {
      
        const vendaResult = await Banco.query(
            'INSERT INTO venda (codcli) VALUES ($1) RETURNING codigo',
            [req.session.usuario.codigo]
        );
        
        const codVenda = vendaResult.rows[0].codigo;
        let totalVenda = 0;

      
        for (const item of req.session.carrinho) {
            
            const produtoResult = await Banco.query(
                'SELECT qtde FROM produto WHERE codigo = $1',
                [item.codigo]
            );

            if (produtoResult.rows[0].qtde < item.qtde) {
                throw new Error('Produto sem estoque suficiente');
            }

           
            await Banco.query(
                'INSERT INTO item (qtde, precounit, codproduto, codvenda) VALUES ($1, $2, $3, $4)',
                [item.qtde, item.preco, item.codigo, codVenda]
            );

           
            await Banco.query(
                'UPDATE produto SET qtde = qtde - $1 WHERE codigo = $2',
                [item.qtde, item.codigo]
            );

            totalVenda += item.preco * item.qtde;
        }

        await Banco.query(
            'UPDATE venda SET total = $1 WHERE codigo = $2',
            [totalVenda, codVenda]
        );

        
        req.session.carrinho = [];

        res.render('finalizar-compra', {
            sucesso: true,
            codigoVenda: codVenda,
            total: totalVenda
        });

    } catch (erro) {
        console.error(erro);
        res.render('finalizar-compra', {
            sucesso: false,
            mensagem: erro.message
        });
    }
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        message: 'Erro interno do servidor',
        error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});

app.listen(3000, () => console.log('Servidor rodando na porta 3000'));
