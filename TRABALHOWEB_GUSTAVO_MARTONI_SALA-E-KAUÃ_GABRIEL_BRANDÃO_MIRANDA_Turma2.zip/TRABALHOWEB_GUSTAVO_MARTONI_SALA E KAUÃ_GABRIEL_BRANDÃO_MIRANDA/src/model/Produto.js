module.exports = class Produto{
    codigo
    descricao
    preco
    qtde
    imagem
    coddep 
}