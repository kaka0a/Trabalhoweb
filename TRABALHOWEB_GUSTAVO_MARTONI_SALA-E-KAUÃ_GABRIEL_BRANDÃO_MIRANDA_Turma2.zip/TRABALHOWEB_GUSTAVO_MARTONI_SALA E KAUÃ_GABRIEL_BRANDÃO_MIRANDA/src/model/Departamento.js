module.exports = class Departamento{
    codigo
    nome
}