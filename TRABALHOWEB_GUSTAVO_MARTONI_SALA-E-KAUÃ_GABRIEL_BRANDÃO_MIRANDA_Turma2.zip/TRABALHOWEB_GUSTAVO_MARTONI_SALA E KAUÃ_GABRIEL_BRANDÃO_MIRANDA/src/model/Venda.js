class Venda {
    constructor(codigo, codigoCliente, data, total, itens) {
        this.codigo = codigo;           
        this.codigoCliente = codigoCliente;  
        this.data = data;               
        this.total = total;              
        this.itens = itens || [];        
    }

    adicionarItem(item) {
        this.itens.push(item);
        this.total += item.quantidade * item.preco;
    }

    calcularTotal() {
        let total = 0;
        for (let item of this.itens) {
            total += item.quantidade * item.preco;
        }
        this.total = total;
    }
}

module.exports = Venda;
