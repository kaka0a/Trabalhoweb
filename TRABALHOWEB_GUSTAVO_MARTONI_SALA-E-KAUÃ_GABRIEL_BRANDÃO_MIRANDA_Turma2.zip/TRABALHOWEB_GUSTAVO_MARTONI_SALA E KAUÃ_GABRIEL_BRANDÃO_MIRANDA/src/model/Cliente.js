module.exports = class Cliente{
    codigo
    nome
    login
    senha
}
