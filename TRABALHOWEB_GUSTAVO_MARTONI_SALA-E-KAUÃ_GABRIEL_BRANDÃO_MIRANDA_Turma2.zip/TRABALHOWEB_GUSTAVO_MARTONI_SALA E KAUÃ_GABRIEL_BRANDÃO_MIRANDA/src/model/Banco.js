const { Pool } = require('pg');

class Banco {
    static pool = null;
    static conexao = null;
    
    static init() {
        if (!this.pool) {
            this.pool = new Pool({
                user: 'postgres',
                host: '127.0.0.1',
                database: 'node',
                password: 'ifsp',
                port: 5432
            });
        }
        return this.pool;
    }
    
    static async query(sql, params) {
        const pool = this.init();
        const client = await pool.connect();
        try {
            const result = await client.query(sql, params);
            return result;
        } catch (erro) {
            console.error("Erro na query:", erro);
            throw erro;
        } finally {
            client.release();
        }
    }
}

module.exports = Banco;