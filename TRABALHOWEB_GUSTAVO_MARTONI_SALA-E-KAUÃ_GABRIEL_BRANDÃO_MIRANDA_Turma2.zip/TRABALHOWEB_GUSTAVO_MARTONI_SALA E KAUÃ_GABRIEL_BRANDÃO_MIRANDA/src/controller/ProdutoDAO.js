const Banco = require("../model/Banco");

module.exports = class ProdutoDAO {

    async listar(codDepartamento) {
        try {
            const tabela = await Banco.query(
                'SELECT codigo, descricao, preco, qtde, imagem, coddep FROM produto WHERE coddep = $1 ORDER BY descricao', 
                [codDepartamento]
            );
            return tabela.rows;
        } catch (erro) {
            console.log("Erro ao listar produtos: " + erro);
            throw erro;
        }
    }

    async buscarPorCodigo(codigoProduto) {
        try {
            const tabela = await Banco.query(
                'SELECT codigo, descricao, preco, qtde, imagem, coddep FROM produto WHERE codigo = $1', 
                [codigoProduto]
            );
            return tabela.rows[0] || null;
        } catch (erro) {
            console.log("Erro ao buscar produto por código: " + erro);
            throw erro;
        }
    }
}
