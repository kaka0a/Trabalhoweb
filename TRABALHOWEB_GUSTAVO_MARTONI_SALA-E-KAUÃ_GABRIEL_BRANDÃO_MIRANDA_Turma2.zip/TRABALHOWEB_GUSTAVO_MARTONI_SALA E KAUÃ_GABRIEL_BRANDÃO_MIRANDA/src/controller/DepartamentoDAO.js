const Banco = require("../model/Banco")

module.exports = class DepartamentoDAO {

    async listar() {
        try {
            const resultado = await Banco.query('SELECT codigo, nome FROM departamento ORDER BY nome');
            return resultado.rows;
        } catch (erro) {
            console.log("Erro no listar departamento: " + erro);
            throw erro;
        }
    }
}