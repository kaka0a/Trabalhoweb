// ItemDAO.js
const Banco = require("../model/Banco");
const Item = require('../model/Item');

class ItemDAO {
    async adicionarItem(codVenda, item) {
        try {
            await Banco.query(
                'INSERT INTO item(codvenda, codproduto, qtde, precounit) VALUES($1, $2, $3, $4)',
                [codVenda, item.id, item.quantidade, item.preco]
            );
        } catch (erro) {
            console.error("Erro ao adicionar item:", erro);
            throw erro;
        }
    }

    async listarItensPorVenda(codVenda) {
        try {
            const result = await Banco.query(
                'SELECT i.*, p.descricao FROM item i JOIN produto p ON i.codproduto = p.codigo WHERE i.codvenda = $1',
                [codVenda]
            );
            return result.rows;
        } catch (erro) {
            console.error("Erro ao listar itens:", erro);
            throw erro;
        }
    }
}

module.exports = new ItemDAO();
