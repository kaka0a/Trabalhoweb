const Banco = require("../model/Banco");

module.exports = class VendaDAO {
    async criar(venda) {
        const client = await Banco.init().connect();
        try {
            await client.query('BEGIN');
            
            // Validar estoque
            for (let item of venda.itens) {
                const estoque = await client.query(
                    'SELECT qtde FROM produto WHERE codigo = $1 FOR UPDATE',
                    [item.id]
                );
                
                if (!estoque.rows[0] || estoque.rows[0].qtde < item.quantidade) {
                    throw new Error(`Produto ${item.id} sem estoque suficiente`);
                }
            }
            
            // Criar venda
            const resVenda = await client.query(
                'INSERT INTO venda(codcli, total, datav) VALUES($1, $2, CURRENT_TIMESTAMP) RETURNING codigo',
                [venda.codigoCliente, venda.total]
            );
            
            const codVenda = resVenda.rows[0].codigo;
            
            // Inserir itens
            for (let item of venda.itens) {
                await client.query(
                    'INSERT INTO item(codproduto, qtde, precounit, codvenda) VALUES($1, $2, $3, $4)',
                    [item.id, item.quantidade, item.preco, codVenda]
                );
                
                await client.query(
                    'UPDATE produto SET qtde = qtde - $1 WHERE codigo = $2',
                    [item.quantidade, item.id]
                );
            }
            
            await client.query('COMMIT');
            return resVenda.rows[0];
        } catch (erro) {
            await client.query('ROLLBACK');
            throw erro;
        } finally {
            client.release();
        }
    }
}
