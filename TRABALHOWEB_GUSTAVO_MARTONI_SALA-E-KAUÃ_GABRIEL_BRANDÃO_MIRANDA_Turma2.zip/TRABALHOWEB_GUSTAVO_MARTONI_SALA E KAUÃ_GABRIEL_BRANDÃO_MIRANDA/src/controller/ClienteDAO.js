const Banco = require("../model/Banco");
const Cliente = require("../model/Cliente");

module.exports = class ClienteDAO {

 
  async gravar(obj) {
    try {
      const res = await Banco.query(
        'INSERT INTO cliente(nome, login, senha) VALUES($1, $2, $3) RETURNING codigo', 
        [obj.nome, obj.login, obj.senha]
      );
      return res.rows[0].codigo; 
    } catch (erro) {
      console.log("Erro ao gravar cliente: ", erro);
      throw erro;
    }
  }

  
  async login(vlogin, vsenha) {
    try {
      const tabela = await Banco.query(
        'SELECT codigo, nome, login FROM cliente WHERE login = $1 AND senha = $2',
        [vlogin, vsenha]
      );
      
      if (tabela.rows.length > 0) {
        const obj = new Cliente(); 
        obj.codigo = tabela.rows[0].codigo;
        obj.nome = tabela.rows[0].nome;
        obj.login = tabela.rows[0].login;
        return obj; 
      }
      return null; 
    } catch (erro) {
      console.log("Erro ao fazer login: ", erro);
      throw erro;
    }
  }

 
  async buscarPorLogin(login) {
    try {
      const tabela = await Banco.query(
        'SELECT * FROM cliente WHERE login = $1',
        [login]
      );
      return tabela.rows.length > 0 ? tabela.rows[0] : null; 
    } catch (erro) {
      console.log("Erro ao buscar cliente por login: ", erro);
      throw erro;
    }
  }
};
